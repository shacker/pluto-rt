from django.test import TestCase


def test_something():
    """
    TODO: Add real tests
    """
    assert 1 == 1

