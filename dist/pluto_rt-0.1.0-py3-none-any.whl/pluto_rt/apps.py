from django.apps import AppConfig


class PlutoRTConfig(AppConfig):
    name = "pluto_rt"
    default_auto_field = 'django.db.models.AutoField'

