from django.apps import AppConfig


class RTConfig(AppConfig):
    name = "proj_1.pluto"
    default_auto_field = 'django.db.models.AutoField'

